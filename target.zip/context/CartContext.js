import React, { createContext, useContext, useState } from 'react';

const CartContext = createContext();

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);

  const addToCart = (product) => {
    setCartItems(currentItems => [...currentItems, product]);
  };

  const removeFromCart = (productId) => {
    setCartItems(currentItems => currentItems.filter(item => item.id !== productId));
  };

  const clearCart = () => {
    setCartItems([]);
  };
  const updateItemQuantity = async (itemId, quantity) => {
    if (user) {
      const cartRef = doc(db, "carts", user.uid);
      const cartSnap = await getDoc(cartRef);

      if (cartSnap.exists()) {
        const cartData = cartSnap.data();
        const itemIndex = cartData.items.findIndex((item) => item.id === itemId);

        if (itemIndex !== -1) {
          const updatedItems = [...cartData.items];
          updatedItems[itemIndex].quantity = quantity;

          await updateDoc(cartRef, {
            items: updatedItems,
          });
        }
      }
    }
  };
  return (
    <CartContext.Provider value={{ cartItems, addToCart, removeFromCart, clearCart, updateItemQuantity }}>
      {children}
    </CartContext.Provider>
  );
};
