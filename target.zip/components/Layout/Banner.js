import { AuthContext } from "@/context/AuthContext";
import { ShoppingCartContext } from "@/context/ShoppingCartContext";
import { doc, getDoc } from "firebase/firestore";
import React, { useContext, useState, useEffect } from "react";
import { db } from "@/firebase/config";
import { FiMenu } from "react-icons/fi";
import Link from "next/link";
import Logo from "../Logo";
import { FaUserCircle, FaChevronDown } from "react-icons/fa";

export function Banner() {
  const { user } = useContext(AuthContext);
  const { cartItems } = useContext(ShoppingCartContext);
  const [userData, setUserData] = useState(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  useEffect(() => {
    if (user) {
      const userRef = doc(db, "users", user.uid);
      getDoc(userRef).then((doc) => {
        if (doc.exists) {
          setUserData(doc.data());
        }
      });
    }
  }, [user]);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  return (
    <div className="sticky top-0 bg-[#fff] z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between py-3">
          {/* Desktop & Tablet */}
          <div className="hidden md:flex items-center">
            <Logo className="h-8 w-8 text-white" />
            <Link href="#">
              <span className="text-white text-sm font-medium hover:underline cursor-pointer">
                Categories
              </span>
            </Link>
            {/* Additional links */}
          </div>
          {/* Mobile */}
          <div className="flex items-center justify-between w-full">
            <FiMenu className="h-6 w-6" />
            <div className="flex-grow text-center hidden">
              <svg viewBox="0 0 32 32" width="48px" className="inline-block">
                <image
                  height="100%"
                  href="https://www.target.com/icons/assets/decorative/light/BullseyeRed.svg#BullseyeRed"
                  width="100%"
                ></image>
              </svg>
            </div>
            {!user && (
              <div className="flex items-center">
                <div className="relative">
                  <button
                    className="flex items-center focus:outline-none"
                    onClick={toggleDropdown}
                  >
                    <FaUserCircle className="w-6 h-6 mr-1" />
                    <FaChevronDown className="w-3 h-3" />
                  </button>
                  {isDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg z-10">
                      <Link
                        href="/login"
                        className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      >
                        Login
                      </Link>
                      <Link
                        href="/signup"
                        className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      >
                        Sign Up
                      </Link>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
          <div className="flex space-x-4 items-center">
            {user && <span className="hidden sm:block md:block ext-sm">Hi, {user.email}</span>}
            <Link href="/cart" className="relative">
              <svg viewBox="0 0 32 32" width="24px">
                <image
                  height="100%"
                  href="https://www.target.com/icons/assets/glyph/Cart.svg#Cart"
                  width="100%"
                ></image>
              </svg>
              {cartItems.length > 0 && (
                <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-red-100 transform translate-x-1/2 -translate-y-1/2 bg-red-600 rounded-full">
                  {cartItems.length}
                </span>
              )}
            </Link>
          </div>
          {/* Hide Logo on small screens and display it in the middle */}
          <div className="md:hidden absolute left-1/2 transform -translate-x-1/2 top-3">
            <Logo className="h-8 w-8 md:hidden" />
          </div>
        </div>
        {/* Responsive Search Bar */}
        <div className="md:hidden mt-3">
          <div className="flex items-center bg-white px-3 py-1.5 rounded-md w-full">
            <input
              className="outline-none border-none flex-grow"
              placeholder="What can we help you find?"
              type="text"
            />
          </div>
        </div>
      </div>
    </div>
  );
}