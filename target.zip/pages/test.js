import Image from 'next/image';

export default function ProductPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row">
        <div className="md:w-1/2">
          <div className="flex items-center justify-center mb-6">
            <Image
              src="/images/nespresso-vertuoplus.jpg"
              alt="Nespresso VertuoPlus Coffee Maker and Espresso Machine"
              width={500}
              height={500}
            />
          </div>
          <div className="flex justify-center space-x-4">
            <Image src="/images/coffee-mug.jpg" alt="Coffee Mug" width={80} height={80} />
            <Image src="/images/coffee-pods.jpg" alt="Coffee Pods" width={80} height={80} />
            <Image src="/images/coffee-maker.jpg" alt="Coffee Maker" width={80} height={80} />
          </div>
        </div>
        <div className="md:w-1/2 md:pl-8">
          <h1 className="text-3xl font-extrabold tracking-tight text-gray-900 mb-4">
            Nespresso VertuoPlus Coffee Maker and Espresso Machine by DeLonghi Black Matte
          </h1>
          <div className="flex items-center mb-4">
            <span className="text-lg font-bold text-red-600">$199.99</span>
            <span className="ml-2 text-gray-500 line-through">$399.99</span>
          </div>
          <div className="mb-6">
            <span className="text-gray-500">When purchased online</span>
            <button className="ml-4 bg-red-600 text-white px-4 py-2 rounded">See 1 deal for this item</button>
          </div>
          <div className="flex justify-between mb-6">
            <div className="flex items-center">
              <Image src="/images/pickup.svg" alt="Pickup" width={24} height={24} />
              <span className="ml-2">Pickup</span>
            </div>
            <div className="flex items-center">
              <Image src="/images/delivery.svg" alt="Delivery" width={24} height={24} />
              <span className="ml-2">Delivery</span>
            </div>
            <div className="flex items-center">
              <Image src="/images/shipping.svg" alt="Shipping" width={24} height={24} />
              <span className="ml-2">Shipping</span>
            </div>
          </div>
          <div className="mb-6">
            <p>Pick up at Reynoldsburg</p>
            <p className="text-gray-500">Ready within 2 hours for pickup inside the store</p>
            <p>Only 5 left</p>
          </div>
          <div className="flex items-center mb-6">
            <label htmlFor="quantity" className="mr-2">Qty:</label>
            <select id="quantity" className="border border-gray-300 rounded px-2 py-1">
              <option>1</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
              <option>5</option>
            </select>
          </div>
          <button className="bg-red-600 text-white px-6 py-3 rounded-full text-lg font-bold mb-6">
            Add to cart
          </button>
          <div className="mb-6">
            <h3 className="text-lg font-bold mb-2">2 Year Electronics Protection Plan ($175-$199.99) - Allstate</h3>
            <p className="text-gray-500">$39.00 - See plan details</p>
          </div>
          <div>
            <h3 className="font-bold mb-2">$139.99 price in cart on Nespresso VertuoPlus with Target Circle</h3>
            <p className="text-gray-500">In-store & Online - Details</p>
          </div>
          <div className="mb-6">
            <h3 className="font-bold mb-2">Save 5% every day</h3>
            <p className="text-gray-500">With RedCard</p>
          </div>
          <div>
            <p>Pay as low as $19/mo</p>
            <p className="text-gray-500">With Affirm</p>
          </div>
          <p className="text-gray-500">At a glance</p>
          <p>Wedding Registry Favorites</p>
        </div>
      </div>
    </div>
  );
}